package com.example.authapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvResult: TextView
    private var loginAttempts = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Инициализация элементов
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvResult = findViewById(R.id.tvResult)

        // Добавляем слушатели изменений текста
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                validateFields()
            }
        }

        etUsername.addTextChangedListener(textWatcher)
        etPassword.addTextChangedListener(textWatcher)

        // Обработка нажатия кнопки
        btnLogin.setOnClickListener {
            loginAttempts++
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()

            if (validateInput(username, password)) {
                // Успешная авторизация
                showSuccess(username)
            }
        }
    }

    private fun validateFields() {
        val username = etUsername.text.toString()
        val password = etPassword.text.toString()

        // Активируем кнопку только если оба поля заполнены
        btnLogin.isEnabled = username.isNotEmpty() && password.isNotEmpty()
    }

    private fun validateInput(username: String, password: String): Boolean {
        return when {
            username.isEmpty() -> {
                tvResult.text = "Будь ласка, введіть логін"
                false
            }
            password.isEmpty() -> {
                tvResult.text = "Будь ласка, введіть пароль"
                false
            }
            password.length < 6 -> {
                tvResult.text = "Пароль має містити щонайменше 6 символів"
                false
            }
            username != "admin" || password != "1234" -> {
                tvResult.text = "Неправильний логін або пароль (спроба $loginAttempts)"
                false
            }
            else -> true
        }
    }

    private fun showSuccess(username: String) {
        tvResult.text = "Вхід успішний!"
        tvResult.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))

        // Показываем Toast с именем пользователя
        Toast.makeText(this, "Вітаємо, $username!", Toast.LENGTH_SHORT).show()

        // Меняем фон на зеленый (временно)
        window.decorView.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_green_light))

        // Через 2 секунды возвращаем обычный фон
        Handler(Looper.getMainLooper()).postDelayed({
            window.decorView.setBackgroundColor(ContextCompat.getColor(this, android.R.color.background_light))
        }, 2000)
    }
}